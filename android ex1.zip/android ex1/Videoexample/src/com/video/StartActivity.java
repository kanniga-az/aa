
package com.video;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.MediaController;
import android.widget.VideoView;

public class StartActivity extends Activity {
   private VideoView mVideoView;
   Button next;
   @Override
   public void onCreate(Bundle icicle) {
     super.onCreate(icicle);
     setContentView(R.layout.main);
     
/*     
     mVideoView = (VideoView) findViewById(R.id.videoview);
    // mediaController.setAnchorView(mVideoView);
     mVideoView.setMediaController(new MediaController(this));
     
//     Uri video1 = Uri.parse("android.resource://" + getPackageName() + "/"+ R.raw.jingle);
     Uri video = Uri.parse("http://119.226.99.174:8040/vprbbc24.mp3");
   //  Uri video = Uri.parse("http://172.24.2.195/tamilsong.mp3");
//     Uri video = Uri.parse("http://vprbbc.streamguys.net:80/vprbbc24.mp3");
//     Uri video = Uri.parse("http://www.pocketjourney.com/audio.mp3");
     
     
     mVideoView.setVideoURI(video);
     mVideoView.requestFocus();
     System.out.println("URI used - "+video);
//     mVideoView.setVideoURI(video);
     mVideoView.start();
     
*/   VideoView videoView = (VideoView) findViewById(R.id.videoview);
     MediaController mediaController = new MediaController(this);
     mediaController.setAnchorView(videoView);
     // Set video link (mp4 format )
     Uri video = Uri.parse("http://www.metacafe.com/watch/929641/santa_claus_singing_his_favorite_christmas_song/");
     System.out.println("Video Player is " +video);
     videoView.setMediaController(mediaController);
     videoView.setVideoURI(video);
     videoView.requestFocus();
     videoView.start();

   }
}