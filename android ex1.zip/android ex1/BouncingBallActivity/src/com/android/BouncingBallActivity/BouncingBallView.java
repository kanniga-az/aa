package com.android.BouncingBallActivity;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.view.View;

public class BouncingBallView extends View {
	   private int xMin = 0;          // This view's bounds
	   private int xMax;
	   private int yMin = 0;
	   private int yMax;
  	   private int xMin1 = 5;          // This view's bounds
	   private int xMax1;
	   private int yMin1 = 5;
	   private int yMax1;
	   private int xMin2 = 10;          // This view's bounds
	   private int xMax2;
	   private int yMin2 = 10;
	   private int yMax2;
	   private float ballRadius = 30; // Ball's radius
	   private float ballX = ballRadius + 20;  // Ball's center (x,y)
	   private float ballY = ballRadius + 40;
	   private float ballRadius1 = 20; // Ball's radius
	   private float ballX1 = ballRadius1 +20;  // Ball's center (x,y)
	   private float ballY1 = ballRadius1 + 40;
	   
	   private float ballRadius2 = 10; // Ball's radius
	   private float ballX2 = ballRadius2 +20;  // Ball's center (x,y)
	   private float ballY2 = ballRadius2 + 40;
	   private float ballSpeedX = 1;  // Ball's speed (x,y)
	   private float ballSpeedY = 3;
	   private float ballSpeedX1 = 1;  // Ball's speed (x,y)
	   private float ballSpeedY1 = 3;
	   private float ballSpeedX2 = 1;  // Ball's speed (x,y)
	   private float ballSpeedY2 = 3;
	   private RectF ballBounds;  
	   private RectF ballBounds1; 
	   private RectF ballBounds2; // Needed for Canvas.drawOval
	   private Paint paint;           // The paint (e.g. style, color) used for drawing
	   
	   // Constructor
	   public BouncingBallView(Context context) {
	      super(context);
	      ballBounds = new RectF();
	      ballBounds1 = new RectF();
	      ballBounds2 = new RectF();
	      paint = new Paint();
	      
	      
	   }
	  
	   // Called back to draw the view. Also called by invalidate().

	   protected void onDraw(Canvas canvas) {
	      // Draw the ball
	      ballBounds.set(ballX-ballRadius, ballY-ballRadius, ballX+ballRadius, ballY+ballRadius);
	      paint.setColor(Color.GREEN);
	      canvas.drawOval(ballBounds, paint);
	      ballBounds1.set(ballX1-ballRadius1, ballY1-ballRadius1, ballX1+ballRadius1, ballY1+ballRadius1);
	      paint.setColor(Color.BLUE);
	      canvas.drawOval(ballBounds1, paint);
	      ballBounds2.set(ballX2-ballRadius2, ballY1-ballRadius2, ballX2+ballRadius2, ballY2+ballRadius2);
	      paint.setColor(Color.RED);
	      canvas.drawOval(ballBounds2, paint);
	      // Update the position of the ball, including collision detection and reaction.
	      update();
	  
	      // Delay
	      try {  
	         Thread.sleep(30);  
	      } catch (InterruptedException e) { }
	      
	      invalidate();  // Force a re-draw
	   }
	   
	   // Detect collision and update the position of the ball.
	   private void update() {
	      // Get new (x,y) position
	      ballX += ballSpeedX;
	      ballY += ballSpeedY;
	      // Detect collision and react
	      if (ballX + ballRadius > xMax) {
	         ballSpeedX = -ballSpeedX;
	         ballX = xMax-ballRadius;
	      } else if (ballX - ballRadius < xMin) {
	         ballSpeedX = -ballSpeedX;
	         ballX = xMin+ballRadius;
	      }
	      if (ballY + ballRadius > yMax) {
	         ballSpeedY = -ballSpeedY;
	         ballY = yMax - ballRadius;
	      } else if (ballY - ballRadius < yMin) {
	         ballSpeedY = -ballSpeedY;
	         ballY = yMin + ballRadius;
	      }
	      
	      
	      ballX1 += ballSpeedX1;
	      ballY1 += ballSpeedY1;
	      // Detect collision and react
	      if (ballX1 + ballRadius1 > xMax1) {
	         ballSpeedX1 = -ballSpeedX1;
	         ballX1 = xMax1-ballRadius1;
	      } else if (ballX1 - ballRadius1 < xMin1) {
	         ballSpeedX1 = -ballSpeedX1;
	         ballX1 = xMin1+ballRadius1;
	      }
	      if (ballY1 + ballRadius1 > yMax1) {
	         ballSpeedY1 = -ballSpeedY1;
	         ballY1 = yMax1 - ballRadius1;
	      } else if (ballY1 - ballRadius1 < yMin1) {
	         ballSpeedY1 = -ballSpeedY1;
	         ballY1 = yMin1 + ballRadius1;
	      }
	      
	      
	      
	      ballX2 += ballSpeedX2;
	      ballY2 += ballSpeedY2;
	      // Detect collision and react
	      if (ballX2 + ballRadius2 > xMax2) {
	         ballSpeedX2 = -ballSpeedX2;
	         ballX2 = xMax2-ballRadius2;
	      } else if (ballX2 - ballRadius2 < xMin2) {
	         ballSpeedX2 = -ballSpeedX2;
	         ballX2 = xMin2+ballRadius2;
	      }
	      if (ballY2 + ballRadius2 > yMax2) {
	         ballSpeedY2 = -ballSpeedY2;
	         ballY2 = yMax2 - ballRadius2;
	      } else if (ballY2 - ballRadius2 < yMin2) {
	         ballSpeedY2 = -ballSpeedY2;
	         ballY2 = yMin2 + ballRadius2;
	      }
	   }
	   
	   
	   
	 
	   
	   
	   // Called back when the view is first created or its size changes.
	   @Override
	   public void onSizeChanged(int w, int h, int oldW, int oldH) {
	      // Set the movement bounds for the ball
	      xMax = w-1;
	      yMax = h-1;
	      xMax1 = w-1;
	      yMax1 = h-1;
	      xMax2 = w-1;
	      yMax2 = h-1;
	   }
	}