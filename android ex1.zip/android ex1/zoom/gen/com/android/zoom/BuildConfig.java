/** Automatically generated file. DO NOT MODIFY */
package com.android.zoom;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}