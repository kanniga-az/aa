package com.android.passingvalue;

import android.app.Activity;
import android.os.Bundle;
import android.widget.TextView;

public class searchresult extends Activity{
	
	public void onCreate(Bundle savedInstanceState) {
	    super.onCreate(savedInstanceState);
	    setContentView(R.layout.searchresult);
	
	Bundle b = getIntent().getExtras();
    int value = b.getInt("state", 0);
    String name = b.getString("name");
       
    TextView vw1 = (TextView) findViewById(R.id.txtName);
    TextView vw2 = (TextView) findViewById(R.id.txtState);
    
     vw1.setText("Name: " + name);
    vw2.setText("State: " + String.valueOf(value));
}

}

