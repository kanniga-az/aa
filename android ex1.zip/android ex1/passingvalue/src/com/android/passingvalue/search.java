package com.android.passingvalue;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class search extends Activity {
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.search);
        Button search = (Button) findViewById(R.id.btnSearch);
        search.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                 
                Intent intent = new Intent( search.this, searchresult.class); 
                Bundle b = new Bundle();
                 
                EditText txt1 = (EditText) findViewById(R.id.edittext);
                EditText txt2 = (EditText) findViewById(R.id.edittext2);
                            
                b.putString("name", txt1.getText().toString());
                b.putInt("state", Integer.parseInt(txt2.getText().toString())); 
                   
                //Add the set of extended data to the intent and start it
                intent.putExtras(b);
                startActivity(intent); 
            }

        });
    }
}