package com.android.listch;

import android.os.Bundle;
import android.app.Activity;
import android.app.ListActivity;
import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.support.v4.app.NavUtils;

public class MainActivity extends ListActivity{

Cursor cursor;
SQLiteDatabase dh;
CustomCursorAdapter myCursorAdapter;
ContentValues values;
@Override
protected void onCreate(Bundle savedInstanceState) {
super.onCreate(savedInstanceState);
AndroidContext.setContext(this);

dh=DatabaseHelper.getInstance().getDb();
values = new ContentValues();
// Inserting some data in SQLite to populate list view
insertData("Avinash","12345");
insertData("Rakesh" ,"qwerty");
insertData("Prateek","onMobile");
insertData("Rajesh","Symphony");
insertData("Rahul","password123");
insertData("Kanishk","_smi1234");
insertData("Ahmad","asdfgh");
insertData("Akkie","zxcvbn");
insertData("Ankur","asdadd");
insertData("Rohit","bigb");
insertData("Abhi","rajjwe");
insertData("Sone","qwerty");
createListView();
}

@SuppressWarnings("deprecation")
private void createListView() {
setContentView(R.layout.activity_main);

cursor=dh.query(DatabaseHelper.USER_PASSWORD, new String[]{"_id","username","selected"}, null, null, null, null, "firstname asc");

startManagingCursor(cursor);
myCursorAdapter= new CustomCursorAdapter(this,cursor);
this.getListView().setAdapter(myCursorAdapter);
}

private void insertData(String firstName ,String password){
if(values!= null){
values.clear();
}
values.put("username",firstName);
values.put("password", password);
dh.insert(DatabaseHelper.USER_PASSWORD, null, values);
}

@SuppressWarnings({ "deprecation", "unused" })
private void clickHandler(View view){

if(view.getId() == R.id.checkbox){
cursor.requery(); /* to get the updated values from sqlite
on changing the check of checkbox*/
}
}

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.activity_main, menu);
        return true;
    }

    
}
