/** Automatically generated file. DO NOT MODIFY */
package com.example.switchbutton;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}