package com.example.switchbutton;

import android.os.Bundle;

import android.app.Activity;
import android.graphics.drawable.TransitionDrawable;
import android.view.Menu;

import android.view.View;
import android.widget.ImageView;
import android.widget.ToggleButton;
import android.view.View.OnClickListener;


public class MainActivity extends Activity {

	@Override
	public void onCreate(final Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);

		final ImageView image = (ImageView) findViewById(R.id.image);
		final ToggleButton button = (ToggleButton) findViewById(R.id.button);
		button.setOnClickListener(new OnClickListener() {
			public void onClick(final View v) {
				TransitionDrawable drawable = (TransitionDrawable) image
						.getDrawable();
				if (button.isChecked()) {
					drawable.startTransition(1000);
				} else {
					drawable.reverseTransition(1000);
				}
			}
		});
	}

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.activity_main, menu);
        return true;
    }

    
}
