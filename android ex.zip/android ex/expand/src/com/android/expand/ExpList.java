package com.android.expand;

import android.app.Activity;

import android.os.Bundle;
import android.widget.SimpleExpandableListAdapter;
import java.util.List;
import java.util.ArrayList;
import java.util.Map;
import java.util.HashMap;

public class ExpList extends Activity {
	 
	
	/** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
      
    }
}