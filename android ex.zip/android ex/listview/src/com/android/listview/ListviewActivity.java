package com.android.listview;




import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.app.Activity;
import android.content.Context;
import android.view.Menu;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ArrayAdapter;
import android.widget.CheckedTextView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

public class ListviewActivity extends Activity implements OnItemClickListener{
    /** Called when the activity is first created. */
	CheckedTextView ctv;
     ListView list;   
     String array[]=new String[]{"a","b","c","d"};
     public void onCreate(Bundle savedInstanceState) {
         super.onCreate(savedInstanceState);
         setContentView(R.layout.main);
        
         list=(ListView)findViewById(R.id.listView1);
         list.setOnItemClickListener(this);
         list.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_list_item_multiple_choice,array));
         
     }
     public void onItemClick(AdapterView<?> parent, View view,
    		 int position, long id) {
    	 
    		 // TODO Auto-generated method stub
    		 Toast.makeText(ListviewActivity.this, array[position], Toast.LENGTH_SHORT).show();
    		 }
    		 
	//public void onItemClick(AdapterView<?> arg0, View arg1, int arg2, long arg3) {
	  
	/*	if(arg2==0)
		{
			AlertDialog.Builder dialog=new AlertDialog.Builder(this);
			dialog.setPositiveButton("ok", new DialogInterface.OnClickListener() 
			
			{
					public void onClick(DialogInterface dialog, int which) {
					System.out.println("a value...........msg inside");
					
				}
			});
			dialog.setMessage("U click a");
			dialog.setTitle("A");
			dialog.show();
			System.out.println("a value...........");
		}
		else if(arg2==1)
		{
			Toast.makeText(ListviewActivity.this, array[arg2], Toast.LENGTH_SHORT).show();
			//Toast.makeText(getApplicationContext(), "" + arg2, Toast.LENGTH_SHORT).show();
		
			
				}
		

*/		}
	




