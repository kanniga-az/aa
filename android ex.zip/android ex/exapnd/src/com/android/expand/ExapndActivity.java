package com.android.expand;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;



import android.app.ExpandableListActivity;
import android.os.Bundle;
import android.widget.ScrollView;
import android.widget.SimpleExpandableListAdapter;

public class ExapndActivity extends ExpandableListActivity {
	static final String colors[] = {
		  "grey",
		  "red",
		  "yellow",
		  "blue",
		  "orange",
		  
		};

		static final String shades[][] = {
	// Shades of grey
		  {
			"lightgrey","#D3D3D3",
			"dimgray","#696969",
			"sgi gray 92","#EAEAEA"
		  },
		// Shades of red
		  {
			"indianred 1","#FF6A6A",
			"firebrick 1","#FF3030",
			"maroon","#800000"
		  },
	
		// Shades of yellow
		  {
			"yellow 1","#FFFF00",
			"gold 1","#FFD700",
			"darkgoldenrod 1","	#FFB90F"
		  },
	
	// Shades of blue
		  {
			"dodgerblue 2","#1C86EE",
			"steelblue 2","#5CACEE",
			"powderblue","#B0E0E6"
		  },
		  //shades of orange
		  {
			  "DarkOrange 1","#FF8C00",
			  "DarkOrchid 1","#9932CC "	
  
		  }
	
	    };
		 public void onCreate(Bundle icicle)
		    {
		        super.onCreate(icicle);
		        setContentView(R.layout.main);
		        
				SimpleExpandableListAdapter expListAdapter =
					new SimpleExpandableListAdapter(
						this,
						createGroupList1(),	// groupData describes the first-level entries
						R.layout.child_row,	// Layout for the first-level entries
						new String[] { "colorName" },	// Key in the groupData maps to display
						new int[] { R.id.childname },		// Data under "colorName" key goes into this TextView
						createChildList1(),	// childData describes second-level entries
						R.layout.child_row,	// Layout for second-level entries
						new String[] { "shadeName", "rgb" },	// Keys in childData maps to display
						new int[] { R.id.childname, R.id.rgb }	// Data under the keys above go into these TextViews
					);
				setListAdapter( expListAdapter );
		    }
		 
		 private List<HashMap<String, String>> createGroupList1() {
			  ArrayList<HashMap<String, String>> result = new ArrayList<HashMap<String, String>>();
			  for( int i = 0 ; i < colors.length ; ++i ) {
				HashMap<String, String> m = new HashMap<String, String>();
			    m.put( "colorName",colors[i] );
				result.add( m );
			  }
			  return (List<HashMap<String, String>>)result;
		    }
		 private List<ArrayList<HashMap<String, String>>> createChildList1() {
				ArrayList<ArrayList<HashMap<String, String>>> result = new ArrayList<ArrayList<HashMap<String, String>>>();
				for( int i = 0 ; i < shades.length ; ++i ) {
			// Second-level lists
				  ArrayList<HashMap<String, String>> secList = new ArrayList<HashMap<String, String>>();
				  for( int n = 0 ; n < shades[i].length ; n +=2) 
				  {
				    HashMap<String, String> child = new HashMap<String, String>();
					child.put( "shadeName", shades[i][n] );
				    child.put( "rgb", shades[i][n+1] );
				    
					secList.add( child );
				  }
				  result.add( secList );
				}
				return result;
			  }
		
}
