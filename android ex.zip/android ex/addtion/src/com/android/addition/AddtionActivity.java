package com.android.addition;


import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class AddtionActivity extends Activity implements OnClickListener{

Button button1;
EditText txtbox1,txtbox2,txtbox3,txtbox4;
TextView tv;

    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        txtbox1=(EditText)findViewById(R.id.txtbox1);
        txtbox1= (EditText) findViewById(R.id.txtbox1);
        button1 = (Button) findViewById(R.id.button1);
        tv = (TextView) findViewById(R.id.lbl1);
        txtbox2= (EditText) findViewById(R.id.txtbox2);
        txtbox3=(EditText)findViewById(R.id.txtbox3);
        txtbox4=(EditText)findViewById(R.id.txtbox4);
        
        button1.setOnClickListener(this);
    }

    public void onClick(View v)
    {
    	String a,b,c,d;
    	Integer vis;
    	a = txtbox1.getText().toString();
    	b = txtbox2.getText().toString();
    	c = txtbox3.getText().toString();
    	d = txtbox4.getText().toString();
    
    	vis = Integer.parseInt(a)+Integer.parseInt(b)+Integer.parseInt(c)-Integer.parseInt(d);
    	tv.setText(vis.toString());}
    	
    
   
    }




        
   
       