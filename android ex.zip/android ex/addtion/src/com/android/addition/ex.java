package com.android.addition;

import android.app.Activity;
import android.os.Bundle;

public class ex extends Activity {
	  public void onCreate(Bundle savedInstanceState) {
	        super.onCreate(savedInstanceState);
	        setContentView(R.layout.ex);
}
}
