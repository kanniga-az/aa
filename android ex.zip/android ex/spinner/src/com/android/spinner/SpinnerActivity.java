package com.android.spinner;



import android.app.Activity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.HorizontalScrollView;
import android.widget.ScrollView;
import android.widget.Spinner;

public class SpinnerActivity extends Activity {
    /** Called when the activity is first created. */
	HorizontalScrollView h;
    Spinner spn;
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        //spn=(Spinner)findViewById(R.id.spinner1);
        ScrollView sView = (ScrollView)findViewById(R.id.ScrollView01);
        
        sView.setVerticalScrollBarEnabled(true);
        sView.setHorizontalScrollBarEnabled(true);
      
        
      
       }
}