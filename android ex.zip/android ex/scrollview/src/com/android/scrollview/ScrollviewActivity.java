package com.android.scrollview;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ScrollView;

public class ScrollviewActivity extends Activity {
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        ScrollView sView = (ScrollView)findViewById(R.id.ScrollView01);
   
     sView.setVerticalScrollBarEnabled(true);
     sView.setHorizontalScrollBarEnabled(true);
     }
    }
